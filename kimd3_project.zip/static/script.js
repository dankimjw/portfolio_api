'use strict';

window.addEventListener('load',function(){
    console.log("Assignment #1");
});